﻿// Variaveis do jogo
var canvas = document.getElementById("mycanvas");
var ctx = canvas.getContext("2d");

canvas.addEventListener('mousemove', moveMouse, false);
canvas.addEventListener('mousedown', cliquePlay, false);



var angulo = 90;	
var forca = 0;
var score =  0;
var gravidade = 0.1;
//Sprites
var posicao = 1;
var num_posicoes = 19;

var estados = {

	jogar: 0,
	jogando: 1,
	perdeu: 2, 
	ganhou: 3,       
}

var estadoAtual = estados.jogar;
//Istancia as imagens do jogo
var imgTerra = new Image();
imgTerra.src = "images/terra.png";

var imgPlay = new Image();
imgPlay.src = "images/play_normal.png";	

var imgLua = new Image();
imgLua.src = "images/lua.png";

var imgBarra = new Image();
imgBarra.src = "images/barra.png";

var imgMeteoro = new Image();
imgMeteoro.src = "images/meteoro2.png";

var imgGameOver = new Image();
imgGameOver.src = "images/perdeu.png";

var imgGanhou = new Image();
imgGanhou.src = "images/ganhou.png";

var imgRecomecar = new Image();
imgRecomecar.src = "images/recomecar.png";					

var spriteFoguete = new Image();


var lua = {										

	altura: 90,
	largura: 90,
	x: 1100,
	y: 100,
	vx: 0,
	vy: 0,
	mov:true							
}

var foguete = {
	
	mov:true,
	altura: 100,
	largura: 100,					
	x: 80,
	y: 520,		
	vx:0,
	vy:0

}
var barraForca = {

	altura:25,
	largura:5,
	x:210,
	y:633
}
var meteoro1 = {
	mov:true,		
	altura: 60,
	largura: 100,
	vx: 0,
	vy: 0,	
	x: 250,
	y: 150
}	
var meteoro2 = {
	mov:true,		
	altura: 60,
	largura: 100,
	vx: 0,
	vy: 0,	
	x: 500,
	y: -500
}	
var meteoro3 = {
	mov:true,		
	altura: 60,
	largura: 100,
	vx: 0,
	vy: 0,	
	x: 800,
	y: -1100
}	
var play = {

	altura:400,
	largura:400,
	x:420,
	y:150

}
var perdeu = {

	altura:600,
	largura:500,
	x:320,
	y:50

}
var ganhou = {

	altura:400,
	largura:500,
	x:400,
	y:100

}
var recomecar = {
	altura:320,
	largura:122,
	x:450,
	y:500
}

//Funcao para mover o mouse
function moveMouse(event){
	cx = event.pageX;
	cy = event.pageY;
	//alert("X,Y =" + cx + ','+ cy);
	
}
// Funcao para clicar
function cliquePlay (evento){
	posX = event.pageX;
	PosY = event.pageY;		
	//alert("X,Y =" + posX + ','+ PosY);
}
//Funcao para trocar de imagem do play 
function btnPlay(event){
	if(cx >= 478 && cx<= 833 && cy >= 234 && cy <= 592){
		imgPlay.src = "images/play_neon.png";
	}	
	else{
		imgPlay.src = "images/play_normal.png";
	}
}

function btnRecomecar(event){
	if(cx >= 489 && cx <= 770 && cy >= 570 && cy <= 682){
		imgRecomecar.src = "images/recomecar_neon.png";
		
	}
	else{
		imgRecomecar.src = "images/recomecar.png";
	}

}
//Funcao para comecar o jogo ao clicar
function clicarBtnPlay(evento){
	//se clicar no botao play...
	if(estadoAtual == estados.jogar && posX >= 478 && posX <=833 && PosY >= 234 && PosY <= 592){
		estadoAtual = estados.jogando;
	}		
}
function clicarBtnRecomecar(evento){
	//se cliclar no botao recomecar...
	if(estadoAtual == estados.perdeu && posX >= 489 && posX <= 770 && PosY >= 570 && PosY <= 682){
		location.reload();			
	}	
}	
//Teclas do jogo		
function moveAngulo(evt){
		//seta para cima
		switch(evt.keyCode){
			case 38:			
			if (posicao > 1 ){                
				posicao--;
				angulo+=10;               	 	
				foguete.vx-=5;


				if(angulo > 360){
					angulo = 10
				}                
			}
			break;            
		}

		//seta para baixo
		switch(evt.keyCode){
			case 40:			
			if (posicao < 9){                
				posicao++; 
				angulo-=10;               	 	            	 	
				foguete.vx += 5;

				if(angulo<10){
					angulo = 360;
				}               
			}
			break;           
		}

		//seta para esquerda
		switch(evt.keyCode){
			case 37:					
			if(forca > 0){					
				barraForca.x -= 5
				forca--;
				foguete.vy--;					
			} 			
			break;
		}

        //seta para direita
        switch(evt.keyCode){
        	case 39:			
        	if(forca < 55){										
        		barraForca.x +=5
        		forca++;				
        		foguete.vy ++
        	}						
        	break;
        }        
        switch(evt.keyCode){
        	case 32:						
        	lanc = setInterval(lancamento,30);
        	//lancamento = false;					
			break;
		}  

	}

	function lancamento(){

		if(foguete.mov == true){
			foguete.vy -= 1;
			foguete.y -= foguete.vy;
			foguete.x += foguete.vx;
		}
		//controla as sprites conforme a gravidade
		if(foguete.vy <0 && posicao < 19 ){		
			posicao++;	
		}

		colideLua();
		colideMeteoro();
}

function colideLua() {
	//se foguete bater na lua...
	if(foguete.x-70 + foguete.largura > lua.x && 
		foguete.x < lua.x + lua.largura && 
		foguete.y + foguete.altura > lua.y &&
		foguete.y < lua.y + lua.altura){

		score++;	
		gravidade = gravidade + 0.05;	
		estadoAtual = estados.ganhou;
		
	}		
}

function colideMeteoro(evt){
	//se foguete bater no meteoro1
	if(	foguete.x  + foguete.largura > meteoro1.x && 
		foguete.x < meteoro1.x + meteoro1.largura && 
		foguete.y + foguete.altura > meteoro1.y &&
		foguete.y < meteoro1.y + meteoro1.altura  || 

		foguete.x  + foguete.largura > meteoro2.x && 
		foguete.x < meteoro2.x + meteoro2.largura && 
		foguete.y + foguete.altura > meteoro2.y &&
		foguete.y < meteoro2.y + meteoro2.altura ||

		foguete.x  + foguete.largura > meteoro3.x && 
		foguete.x < meteoro3.x + meteoro3.largura && 
		foguete.y + foguete.altura > meteoro3.y &&
		foguete.y < meteoro3.y + meteoro3.altura 

		|| foguete.x > canvas.width || foguete.y > canvas.height){	 
		
		estadoAtual = estados.perdeu;
	}
}


function moveMeteoro(){

	//Aplicar gravidade para o asteroide cair
	if(meteoro1.mov == true ){	
		meteoro1.vy += gravidade;
		meteoro1.y += meteoro1.vy ;
	}
	if(meteoro2.mov == true ){	
		meteoro2.vy += gravidade;
		meteoro2.y += meteoro2.vy ;
	}
	if(meteoro3.mov == true ){	
		meteoro3.vy += gravidade;
		meteoro3.y += meteoro3.vy ;
	}
	//fazer o asteroide cair de novo(loop)
	if (meteoro1.y + (meteoro1.altura + meteoro1.largura) > 900) {
		meteoro1.vy = 0;
		meteoro1.y = -100;					
	}
	if (meteoro2.y + (meteoro2.altura + meteoro2.largura) > 900) {
		meteoro2.vy = 0;
		meteoro2.y = -100;					
	}
	if (meteoro3.y + (meteoro3.altura + meteoro3.largura) > 900) {
		meteoro3.vy = 0;
		meteoro3.y = -100;					
	}
}

function desenha(){


	if(estadoAtual == estados.jogar){			
		ctx.clearRect(0, 0, canvas.width, canvas.height);	
		ctx.drawImage(imgPlay, play.x, play.y, play.altura, play.largura); 

	}
	else if(estadoAtual == estados.ganhou){

		clearInterval(lanc);
		ctx.drawImage(imgGanhou, ganhou.x, ganhou.y, ganhou.altura, ganhou.largura);

		setTimeout(function() {
			ctx.clearRect(0, 0, canvas.width, canvas.height);			
			foguete.x = 80;
			foguete.y = 520;
			foguete.vx = 0;
			foguete.vy = 0;
			posicao= 1;
			angulo= 90;
			forca = 0;
			barraForca.x = 210;
			
			
			estadoAtual = estados.jogando;			

		}, 1500);

	}

	else if (estadoAtual == estados.perdeu) {
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		ctx.drawImage(imgGameOver, perdeu.x, perdeu.y, perdeu.altura, perdeu.largura);
		ctx.drawImage(imgRecomecar, recomecar.x, recomecar.y, recomecar.altura, recomecar.largura);  
		ctx.beginPath();
		ctx.fillStyle = "black";
		ctx.font = "40px Arial";		
		ctx.fillText("Score: " + score, 570, 270);           
		foguete.mov = false;					

	} 

	else if (estadoAtual == estados.jogando) {

		ctx.clearRect(0, 0, canvas.width, canvas.height);

		ctx.drawImage(imgTerra, 50,550,100,100);	
		ctx.drawImage(spriteFoguete, foguete.x, foguete.y, foguete.altura, foguete.largura);		
		spriteFoguete.src ="Sprites/" + posicao +".png";
		ctx.drawImage(imgLua, lua.x, lua.y, lua.altura, lua.largura);
		ctx.drawImage(imgMeteoro, meteoro1.x, meteoro1.y, meteoro1.altura, meteoro1.largura);
		ctx.drawImage(imgMeteoro, meteoro2.x, meteoro2.y, meteoro2.altura, meteoro2.largura);
		ctx.drawImage(imgMeteoro, meteoro3.x, meteoro3.y, meteoro3.altura, meteoro3.largura);

		ctx.drawImage(imgBarra, 200, 630,300,31);

		ctx.beginPath();
		ctx.fillStyle = "white"
		ctx.fillRect(barraForca.x,barraForca.y,barraForca.largura,barraForca.altura);	

		ctx.beginPath(); 
		ctx.fillStyle = "yellow";
		ctx.font = "30px Agency FB";		
		ctx.fillText("Score: " + score, 20, 100);
		ctx.fillText("Angulo: " + angulo +" º", 350, 620);
		ctx.fillText("Forca: " + forca, 210, 620);
		
		moveMeteoro();	
		window.addEventListener('keydown', moveAngulo);		
	};

}

function update(){
	requestAnimationFrame(update);
	
	desenha();	
	btnPlay();
	btnRecomecar();
	clicarBtnPlay();
	clicarBtnRecomecar();
}	
update();

