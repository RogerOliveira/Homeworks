<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Maze Store | CONTATO</title>

  <!-- FONT AWESOME (icones)-->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- BOOTSTRAP-->
  <link rel="stylesheet" href="css/bootstrap.min.css">    
  <!--CSS--> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <!--FONT DO GOOGLE-->
  <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 

  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="../dist/aos.css" />

</head>



<body>
 <!--NAVBAR-->
 <header class="clearfix">
  <div class="container">
    <div class="header-left">
      <a href="index.php"><img src="images\logo.png" width="80px"></a>
    </div>
    <div class="header-right">
      <label for="open">
        <span class="hidden-desktop"></span>
      </label>
      <input type="checkbox" name="" id="open">
      <nav>
        <a style="text-decoration: none;" href="index.php"><i class="fa fa-home" aria-hidden="true"></i>  Home</a> 
        <a style="text-decoration: none;" href="pra_elas.php"><i class="fa fa-female" aria-hidden="true"></i> Pra Elas</a>
        <a style="text-decoration: none;" href="pra_eles.php"><i class="fa fa-male" aria-hidden="true"></i> Pra Eles</a>
        <a style="text-decoration: none;" href="unisex.php"><i class="fa fa-female" aria-hidden="true"></i> <i class="fa fa-male" aria-hidden="true"></i> Unisex</a>

      </nav>
    </div>
  </div>
</header>
<!--section class="clearfix">
        <div class="container">
            <div class="section-left">
                
            </div>
            <div class="section-right">
                <button class="learn-more">Learn more</button>
            </div>
        </div>
      </section-->
      <!--FIM-->   

      <!--CONTATO-->
      <div class="row" style="padding-top: 130px;">

        <div class="col-md-3 text-center">
          <img class="img-circle" src=images/social1.png style="width: 177px;">
          <h4>(11) 97450-7986</h4> 
          <h4>(11) 97463-1773</h4>
        </div>

        <div class="col-md-3 text-center">
          <a href="https://www.facebook.com/store.maze/?fref=ts"><img class="img-circle" src=images/social2.png style="width: 180px;"></a>
          <h4>@store.maze</h4>
        </div>

        <div class="col-md-3 text-center">
          <a href="https://www.instagram.com/store.maze/?hl=pt-br"><img class="img-circle" src=images/social3.png style="width: 180px;"></a>
          <h4>@store.maze</h4> 
        </div>

        <div class="col-md-3 text-center">
          <img class="img-circle" src=images/social4.png style="width: 177px;">
          <h4>mazestore@hotmail.com</h4> 
        </div>

      </div>      
    </div>

    <!--FIM-->

    <div id="aos-demo" class="aos-all"></div>

    <script src="../dist/aos.js"></script>
    <script>
      AOS.init({
        easing: 'ease-in-out-sine'
      });

      setInterval(addItem, 300);

      var itemsCounter = 1;
      var container = document.getElementById('aos-demo');

      function addItem () {
        if (itemsCounter > 42) return;
        var item = document.createElement('div');
        item.classList.add('aos-item');
        item.setAttribute('data-aos', 'fade-up');
        item.innerHTML = '<div class="aos-item__inner"><h3>' + itemsCounter + '</h3></div>';
        container.appendChild(item);
        itemsCounter++;
      }
    </script>











    <br><br><br><br>

    <!--RODAPÉ DA PÁGINA-->
    <footer>
      <div class="container text-center">    
        <p style="color: gray">Copyright &copy; 2017 Maze Store. | Designer By Roger Oliveira </p>

      </div>
      <!--FIM-->
    </footer>

    <!-- JAVA SCRITP--> 
    <script type="text/javascript" src="js/jquery-1.12.3.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/home.js"></script>
    <!-- UItoTop plugin VOLTA AO TOP -->
    <script src="js/jquery.ui.totop.js" type="text/javascript"></script>

    <a href="#" id="toTop" style="display: inline; position: right" title="Voltar ao topo" style="stop-color: blue">

      <span id="totopHovert" style="opacity: 0;"></span>

    </a>

  </body>
  </html>



<!--http://lab.mattvarone.com/projects/jquery/totop/-->