<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Maze Store | UNISEX</title>

  <!-- FONT AWESOME (icones)-->
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <!-- BOOTSTRAP-->
  <link rel="stylesheet" href="css/bootstrap.min.css">    
  <!--CSS--> 
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <!--FONT DO GOOGLE-->
  <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 

  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" href="css/styles.css" />
  <link rel="stylesheet" href="../dist/aos.css" />

</head>



<body>
 <!--NAVBAR-->
 <header class="clearfix">
  <div class="container">
    <div class="header-left">
      <a href="index.php"><img src="images\logo.png" width="80px"></a>
    </div>
    <div class="header-right">
      <label for="open">
        <span class="hidden-desktop"></span>
      </label>
      <input type="checkbox" name="" id="open">
      <nav>
        <a style="text-decoration: none;" href="index.php"><i class="fa fa-home" aria-hidden="true"></i>  Home</a>
        <a style="text-decoration: none;" href="pra_elas.php"><i class="fa fa-female" aria-hidden="true"></i> Pra Elas</a>        
        <a style="text-decoration: none;" href="pra_eles.php"><i class="fa fa-male" aria-hidden="true"></i> Pra Eles</a>
        <a style="text-decoration: none;" href="unisex.php"><i class="fa fa-female" aria-hidden="true"></i> <i class="fa fa-male" aria-hidden="true"></i> Unisex</a>
        <a style="text-decoration: none;" href="contato.php"><i class="fa fa-whatsapp" aria-hidden="true"></i></i>  Contato</a>

      </nav>
    </div>
  </div>
</header>

<!--FIM-->   




<div class="col-md-12 text-center">
  <img src="images\unisex2.png" width="185px;" style="padding-top: 20px; padding-bottom: 20px;">
</div>

<!--PRODUTOS-->

<div class="row">

  <div class="col-md-3 text-center">
    <article class="box">
      <div>
        <img src="images\p33.png" style="width: 260px;height: 270px; border-radius: 5px; position: relative;">
        <p>Boné Adidas</p><p></p>
        <p style="color: gray; font-size: 10; padding-top: -10px;">Por R$ 79,99em até 3x</p><p style="color: gray;"> aceitamos <i class="fa fa-credit-card" aria-hidden="true"></i> Cartão e <i class="fa fa-paypal" aria-hidden="true"></i> Paypal </p>  
        <p style="color: #00CD00"><i class="fa fa-truck" aria-hidden="true"></i> Envio para todo o Brasil</p>              
        <p><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" style="font-size: 14px;height:40px;"><i class="fa fa-heart" aria-hidden="true"></i>  Eu quero!</button></p>
      </div>
    </article>
  </div>

  <div class="col-md-3 text-center">
    <article class="box">
      <div>
        <img src="images\p34.png" style="width: 268px; height: 270px; border-radius: 5px; position: relative;">  

        <p>Boné Calvin Klein</p><p></p>
        <p style="color: gray; font-size: 10; padding-top: -10px;">Por R$99,99</p><p style="color: gray;"> aceitamos <i class="fa fa-credit-card" aria-hidden="true"></i> Cartão e <i class="fa fa-paypal" aria-hidden="true"></i> Paypal </p>                   
        <p style="color: #00CD00"><i class="fa fa-truck" aria-hidden="true"></i> Envio para todo o Brasil</p>
        <p><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" style="font-size: 14px;height:40px;"><i class="fa fa-heart" aria-hidden="true"></i>  Eu quero!</button></p>
      </div>
    </article>
  </div>



  <div class="col-md-3 text-center">
    <article class="box">
      <div>
        <img src="images\p35.png" style="width: 300px;height: 270px; border-radius: 5px; position: relative;">
        
        <p>Linha Gucci</p><p></p>
        <p style="color: gray; font-size: 10; padding-top: -10px;">Por R$ 189,99</p><p style="color: gray;"> aceitamos <i class="fa fa-credit-card" aria-hidden="true"></i> Cartão e <i class="fa fa-paypal" aria-hidden="true"></i> Paypal </p>  
        
        <p style="color: #00CD00"><i class="fa fa-truck" aria-hidden="true"></i> Envio para todo o Brasil</p>              
        <p><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" style="font-size: 14px;height:40px;"><i class="fa fa-heart" aria-hidden="true"></i>  Eu quero!</button></p>
      </div>
    </article>
  </div>

  <div class="col-md-3 text-center">
    <article class="box">
      <div>
        <img src="images\p36.png" style="width: 260px;height: 275px; border-radius: 5px; position: relative;">

        <p>Relógio Casio</p><p></p>
        <p style="color: gray; font-size: 10; padding-top: -10px;">Por R$ 89,99 em até 3x</p><p style="color: gray;"> aceitamos <i class="fa fa-credit-card" aria-hidden="true"></i> Cartão e <i class="fa fa-paypal" aria-hidden="true"></i> Paypal </p>
        <p style="color: #00CD00"><i class="fa fa-truck" aria-hidden="true"></i> Envio para todo o Brasil</p>
        <p><button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal" style="font-size: 14px;height:40px;"><i class="fa fa-heart" aria-hidden="true"></i>  Eu quero!</button></p>
      </div>
    </article>
  </div>       

</div>
<!--FIM-->






<!--POP UP BOTAO EU QUERO-->
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><i class="fa fa-shopping-cart" aria-hidden="true"></i>
          Entre em contato conosco para adiquirir este produto !</h4>
        </div>
        <div class="modal-body">

          <!--CONTATO-->
          <div class="row" style="padding-top: 10px;">

            <div class="col-md-3 text-center">
              <img class="img-circle" src=images/social1.png style="width: 70px;">
              <h5>(11) 97450-7986</h5>
              <h5>(11) 97463-1773</h5> 
            </div>

            <div class="col-md-3 text-center">
              <a href="https://www.facebook.com/store.maze/?fref=ts"><img class="img-circle" src=images/social2.png style="width: 70px;"></a>
              <h5>@store.maze</h5>
            </div>

            <div class="col-md-3 text-center">
              <a href="https://www.instagram.com/store.maze/?hl=pt-br"><img class="img-circle" src=images/social3.png style="width: 70px;"></a>
              <h5>@store.maze</h5> 
            </div>

            <div class="col-md-3 text-center">
              <img class="img-circle" src=images/social4.png style="width: 70px;">
              <h6 style="font-size: 11px;">mazestore@hotmail.com</h6> 
            </div>

          </div>      

          <!--FIM-->

        </div>

        <p style="color: gray; padding-left: 10px;padding-top: 20px;"> *Aceitamos <i class="fa fa-credit-card" aria-hidden="true"></i> Cartão e <i class="fa fa-paypal" aria-hidden="true"></i> Paypal. </p>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-arrow-circle-o-left" aria-hidden="true"></i>
            Voltar</button>
          </div>
        </div>

      </div>
    </div>
    <!--FIM-->




    <br><br><br><br>

    <!--RODAPÉ DA PÁGINA-->
    <footer>
      <div class="container text-center">    
        <p style="color: gray">Copyright &copy; 2017 Maze Store. | Designer By Roger Oliveira </p>

      </div>
      <!--FIM-->
    </footer>

    <!-- JAVA SCRITP--> 
    <script type="text/javascript" src="js/jquery-1.12.3.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/home.js"></script>
    <!-- UItoTop plugin VOLTA AO TOP -->
    <script src="js/jquery.ui.totop.js" type="text/javascript"></script>

    <a href="#" id="toTop" style="display: inline; position: right" title="Voltar ao topo" style="stop-color: blue">

      <span id="totopHovert" style="opacity: 0;"></span>

    </a>

  </body>
  </html>



<!--http://lab.mattvarone.com/projects/jquery/totop/-->