package br.com.usjt.watersee.view;

import br.com.usjt.watersee.model.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;
import javax.swing.text.MaskFormatter;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.chrono.JapaneseDate;
import java.util.ArrayList;
import java.util.Vector;

import br.com.usjt.watersee.business.exception.*;

import java.sql.Connection;

public class NivelReservatorio extends JFrame implements ActionListener {
	private JLabel lblRepresa, lblNivel, lblData;
	private JTextField txtNivelTotal;
	private JFormattedTextField txtData;
	private JButton btnCancelar, btnSalvar;
	private JComboBox cbxSistema, cbxRepresa;
	private ArrayList<String> lista;
	private ArrayList<String> lista2;
	private Sistema sistema;
	private Represa represa;
	private Connection conn;
	private ConnectionFactory cf;

	public NivelReservatorio() {
		super("WaterSee | Atualizar N�vel Reservat�rio");

		cf = new ConnectionFactory();
		try {
			conn = cf.conectar();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sistema = new Sistema();
		lista = sistema.carregar(conn);

		cbxSistema = new JComboBox<String>(lista.toArray(new String[0]));
		cbxSistema.setFont(new Font("Century Gothic", 0, 14));
		cbxSistema.setBackground(Color.WHITE);
		cbxSistema.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					conn = cf.conectar();
				} catch (SQLException f) {
					f.printStackTrace();
				}
				represa = new Represa();
				lista2 = represa.carregar(conn,
						(String) cbxSistema.getSelectedItem());
				cbxRepresa.removeAllItems();
				cbxRepresa.setFont(new Font("Century Gothic", 0, 14));
				for (String rep : lista2) {
					cbxRepresa.addItem(rep);
				}

			}
		});
		cbxRepresa = new JComboBox();
		cbxRepresa.setBackground(Color.WHITE);
		lblRepresa = new JLabel("  Represa: ");

		lblNivel = new JLabel("Nivel Total mm�: ");
		lblNivel.setFont(new Font("Century Gothic", 0, 14));
		txtNivelTotal = new JTextField(7);
		txtNivelTotal.setHorizontalAlignment(SwingConstants.RIGHT);
		lblData = new JLabel("    Data: ");
		lblData.setFont(new Font("Century Gothic", 0, 14));
		txtData = new JFormattedTextField();
		txtData.setFont(new Font("Century Gothic", 0, 14));
		txtData.setColumns(6);
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setFont(new Font("Century Gothic", 0, 14));
		btnCancelar.setForeground(Color.WHITE);
		btnCancelar.setBackground(new Color(0, 131, 195));
		btnSalvar = new JButton("Salvar");
		btnSalvar.setFont(new Font("Century Gothic", 0, 14));
		btnSalvar.setForeground(Color.WHITE);
		btnSalvar.setBackground(new Color(54, 100, 139));
		
		try {
			MaskFormatter formater = new MaskFormatter();
			formater.setMask("##/##/####");
			formater.install(txtData);
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(null, "Mascara invalida!");
		}

		// btnSalvar.setIcon(newjavax.swing.ImageIcon(getClass().getResource("save.png")));

		/*btnSalvar.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) { // TODO
				Nivel nivel = new Nivel();
				nivel.setId(id);
				nivel.setNivel(nivel);
				nivel.setRepresa(represa);
				JOptionPane.showMessageDialog(null, "ATUALIZADO COM SUCESSO! ");
			}
		});*/

		// barra do menu
		JMenuBar menuBar = new JMenuBar();

		// Menu
		JMenu menuHome = new JMenu("Home");
		JMenu menuNivel = new JMenu("N�vel Pluviom�trico");
		JMenu menuNivelReservatorio = new JMenu("N�vel Reservat�rio");
		JMenu menuRelatorio = new JMenu("Relatorio");
		JMenu menuSair = new JMenu("Sair");
		menuHome.setFont(new Font("Century Gothic", 0, 14));
		menuNivelReservatorio.setFont(new Font("Century Gothic", 0, 14));
		menuNivel.setFont(new Font("Century Gothic", 0, 14));
		menuRelatorio.setFont(new Font("Century Gothic", 0, 14));
		menuSair.setFont(new Font("Century Gothic", 0, 14));

		menuHome.add(menuBar);
		menuHome.setForeground(Color.WHITE);
		menuNivel.add(menuBar);
		menuNivel.setForeground(Color.WHITE);
		menuNivelReservatorio.add(menuBar);
		menuNivelReservatorio.setForeground(Color.WHITE);
		menuRelatorio.add(menuBar);
		menuRelatorio.setForeground(Color.WHITE);
		menuSair.add(menuBar);
		menuSair.setForeground(Color.WHITE);

		menuBar.add(menuHome);
		menuBar.add(menuNivel);
		menuBar.add(menuNivelReservatorio);
		menuBar.add(menuRelatorio);
		menuBar.add(menuSair);
		menuBar.setBackground(new Color(54, 100, 139));

		menuHome.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();
				new Home();

			}

			public void menuDeselected(MenuEvent e) {

			}

			public void menuCanceled(MenuEvent e) {

			}
		});

		menuNivel.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();

				new AtualizarNivel();

			}

			public void menuDeselected(MenuEvent e) {

			}

			public void menuCanceled(MenuEvent e) {

			}
		});

		menuNivelReservatorio.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();
				new NivelReservatorio();

			}

			public void menuDeselected(MenuEvent e) {

			}

			public void menuCanceled(MenuEvent e) {

			}
		});

		menuRelatorio.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();
				new Relatorio();
			}

			public void menuDeselected(MenuEvent e) {
			}

			public void menuCanceled(MenuEvent e) {
			}
		});

		menuSair.addMenuListener(new MenuListener() {
			public void menuSelected(MenuEvent e) {
				System.exit(0);
			}

			public void menuDeselected(MenuEvent e) {
			}

			public void menuCanceled(MenuEvent e) {
			}
		});

		super.setJMenuBar(menuBar);

		setLayout(new FlowLayout());
		Container caixa = getContentPane();
		// caixa.setLayout(new FlowLayout());
		JPanel painel1 = new JPanel(new FlowLayout());
		painel1.setBackground(Color.WHITE);
		JPanel painel2 = new JPanel(new FlowLayout());
		painel2.setBackground(Color.WHITE);
		JPanel painel3 = new JPanel(new FlowLayout());
		painel3.setBackground(Color.WHITE);
		JPanel painel4 = new JPanel(new GridLayout(3, 1));

		// JPanel painel5 = new JPanel(new FlowLayout());

		JLabel label = new JLabel("Titled Border");
		label.setHorizontalAlignment(JLabel.CENTER);

		TitledBorder titled = new TitledBorder("Atualizar N�vel Reservat�rio");

		titled.setTitleFont(new Font("Century Gothic", 0, 14));
		titled.setTitleColor((new Color(54, 100, 139)));

		painel1.add(cbxSistema);
		painel1.add(cbxRepresa);

		painel2.add(lblNivel);
		painel2.add(txtNivelTotal);
		painel2.add(lblData);
		painel2.add(txtData);

		painel3.add(btnCancelar);
		painel3.add(btnSalvar);

		painel4.add(painel1);
		painel4.add(painel2);
		painel4.add(painel3);
		painel4.setBorder(titled);
		caixa.add(painel4);

		btnCancelar.addActionListener(this);
		btnSalvar.addActionListener(this);

		setSize(560, 420);
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.white);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btnCancelar) {
			dispose();
			new Home();
		}
	}

	public static void main(String[] args) {
		ConnectionFactory cf = new ConnectionFactory();
		try {
			Connection conn = cf.conectar();
			new NivelReservatorio();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
