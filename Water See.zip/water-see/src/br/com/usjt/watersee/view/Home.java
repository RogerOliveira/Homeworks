package br.com.usjt.watersee.view;

import javax.swing.*;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import br.com.usjt.watersee.business.exception.ConnectionFactory;

import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;

@SuppressWarnings("serial")
public class Home extends JFrame implements ActionListener {
	private JMenuBar menuBar;
	private JMenu menuHome, menuNivel;

	private JLabel label;

	public Home() {
		super("WaterSee | Home");

		Image img = new ImageIcon(this.getClass().getResource("logo2.jpg"))
				.getImage();
		label = new JLabel("");
		label.setIcon(new ImageIcon(img));

		// barra do menu
		JMenuBar menuBar = new JMenuBar();

		// Menu
		// JMenu menuHome = new JMenu("Home");
		JMenu menuNivel = new JMenu("N�vel Pluviom�trico");
		JMenu menuNivelReservatorio = new JMenu("N�vel Reservat�rio");
		JMenu menuRelatorio = new JMenu("Relatorio");
		JMenu menuSair = new JMenu("Sair");
		menuNivelReservatorio.setFont(new Font("Century Gothic", 0, 14));
		menuNivel.setFont(new Font("Century Gothic", 0, 14));
		menuRelatorio.setFont(new Font("Century Gothic", 0, 14));
		menuSair.setFont(new Font("Century Gothic", 0, 14));

		
				
		menuNivel.add(menuBar);
		menuNivel.setForeground(Color.WHITE);
		menuNivelReservatorio.add(menuBar);
		menuNivelReservatorio.setForeground(Color.WHITE);
		menuRelatorio.add(menuBar);
		menuRelatorio.setForeground(Color.WHITE);
		menuSair.add(menuBar);
		menuSair.setForeground(Color.WHITE);

		
		menuBar.add(menuNivel);
		menuBar.add(menuNivelReservatorio);
		menuBar.add(menuRelatorio);
		menuBar.add(menuSair);
		menuBar.setBackground(new Color(54,100,139));

		menuNivel.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();

				new AtualizarNivel();

			}

			public void menuDeselected(MenuEvent e) {

			}

			public void menuCanceled(MenuEvent e) {

			}
		});

		menuNivelReservatorio.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();
				new NivelReservatorio();

			}

			public void menuDeselected(MenuEvent e) {

			}

			public void menuCanceled(MenuEvent e) {

			}
		});

		menuRelatorio.addMenuListener(new MenuListener() {

			public void menuSelected(MenuEvent e) {
				dispose();
				new Relatorio();
			}

			public void menuDeselected(MenuEvent e) {
			}

			public void menuCanceled(MenuEvent e) {
			}
		});

		menuSair.addMenuListener(new MenuListener() {
			public void menuSelected(MenuEvent e) {
				System.exit(0);
			}

			public void menuDeselected(MenuEvent e) {
			}

			public void menuCanceled(MenuEvent e) {
			}
		});

		super.setJMenuBar(menuBar);

		Container caixa = getContentPane();
		caixa.setLayout(new FlowLayout());
		JPanel painel = new JPanel(new FlowLayout());

		caixa.add(label, BorderLayout.CENTER);
		caixa.add(painel);
		caixa.setBackground(Color.white);

		setSize(560, 420);
		setResizable(false);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setBackground(Color.white);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void actionPerformed(ActionEvent e) {

	}

	public static void main(String[] args) {

		new Home();
	}

}