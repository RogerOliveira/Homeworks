package br.com.usjt.watersee.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import br.com.usjt.watersee.business.exception.*;

public class Sistema {
	private int id;
	private String nome;
	private String regiao;
	private double nivel;
	

	public Sistema() {
			
	}
	
	public String toString(){
		return nome;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	public double getNivel() {
		return nivel;
	}

	public void setNivel(double nivel) {
		this.nivel = nivel;
	}
	

	public ArrayList<String> carregar(Connection conn)
	{
		ArrayList<String> lista = new ArrayList<String>();
		
		String sqlSelect = "SELECT id_sistema, tx_nome FROM tb_sistema";
		
		try(PreparedStatement stm = conn.prepareStatement(sqlSelect);)
		{	
			ResultSet rs = stm.executeQuery();
			while(rs.next())
			{
				lista.add(rs.getString("tx_nome"));
			}
		}	catch(SQLException e1)
		{
			System.out.print(e1.getStackTrace());
		}
		return lista;
	}
	}
