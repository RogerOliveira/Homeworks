package br.com.usjt.watersee.model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Vector;

import br.com.usjt.watersee.view.AtualizarNivel;
import br.com.usjt.watersee.view.Relatorio;

public class Nivel {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private Represa represa;
	private double nivel;
	private Date atualizacao;

	public Nivel(Represa represa, double nivel, int atualizacao) {

	}

	public Nivel() {

	}

	public String toString() {
		return "Nivel: " + String.valueOf(nivel) + "Data da Atualiza��o: "
				+ String.valueOf(atualizacao);
	}

	public Represa getRepresa() {
		return represa;
	}

	public void setRepresa(Represa represa) {
		this.represa = represa;
	}

	public double getNivel() {
		return nivel;
	}

	public void setNivel(double nivel) {
		this.nivel = nivel;
	}

	public Date getAtualizacao() {
		return atualizacao;
	}

	public void setAtualizacao(Date atualizacao) {
		this.atualizacao = atualizacao;
	}

	public void incluir(Connection conn) {
		String sqlInsert = "INSERT INTO TB_NIVEL VALUES (NULL, ?, ?, ?)";

		try (PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setInt(1, getRepresa().getId());
			stm.setDouble(2, getNivel());
			stm.setDate(3, getAtualizacao());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.print(e1.getStackTrace());
			}
		}
	}
	
	public void alterar(Connection conn) {
		String sqlInsert = "UPDATE TB_NIVEL SET DB_NIVEL_TOTAL ? WHERE ID = ?";

		try (PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
			stm.setDouble(1, getNivel());
			stm.setInt(2, getId());
			stm.execute();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				System.out.print(e1.getStackTrace());
			}
		}
	}

	public ArrayList<Nivel> mostrar(Connection conn,
			java.util.Date dataInicial, String represa, String sistema,
			java.util.Date dataFinal) {
		ArrayList<Nivel> lista = new ArrayList<Nivel>();

		String sqlSelect = "SELECT r.tx_nome, N.id_nivel, N.db_nivel, N.dt_atualizacao FROM tb_nivel N	"
				+ "INNER JOIN tb_represa R ON (R.id_represa = N.id_represa_fk) "
				+ "INNER JOIN tb_sistema S ON (R.id_sistema_fk = S.id_sistema) "
				+ "WHERE R.tx_nome = ? AND S.tx_nome = ? AND "
				+ "dt_atualizacao BETWEEN ? AND ?";

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date parsed = new Date(id);
		try (PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setString(1, sistema);
			stm.setString(2, represa);
			stm.setDate(3, new java.sql.Date(dataInicial.getTime()));
			stm.setDate(4, new java.sql.Date(dataFinal.getTime()));
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				Nivel n = new Nivel();
				Represa r = new Represa();
				r.setNome(rs.getString("tx_nome"));
				n.setId(rs.getInt("id_nivel"));
				n.setNivel(rs.getDouble("db_nivel"));
				n.setAtualizacao(rs.getDate("dt_atualizacao"));
				n.setRepresa(r);
				lista.add(n);
				;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return lista;
	}

	public ArrayList<Nivel> mostrar(Connection conn, String represa,
			String sistema) {
		ArrayList<Nivel> lista = new ArrayList<Nivel>();

		String sqlSelect = "SELECT r.tx_nome, N.id_nivel, N.db_nivel, N.dt_atualizacao FROM tb_nivel N	"
				+ "INNER JOIN tb_represa R ON (R.id_represa = N.id_represa_fk) "
				+ "INNER JOIN tb_sistema S ON (R.id_sistema_fk = S.id_sistema) "
				+ "WHERE R.tx_nome = ? AND S.tx_nome = ?";

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Date parsed = new Date(id);
		try (PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setString(1, sistema);
			stm.setString(2, represa);
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				Nivel n = new Nivel();
				Represa r = new Represa();
				r.setNome(rs.getString("tx_nome"));
				n.setId(rs.getInt("id_nivel"));
				n.setNivel(rs.getDouble("db_nivel"));
				n.setAtualizacao(rs.getDate("dt_atualizacao"));
				n.setRepresa(r);
				lista.add(n);
				;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return lista;
	}

}