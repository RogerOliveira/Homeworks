package br.com.usjt.watersee.model;

public class SistemaMunicipio {
	private Sistema sistema;

	public Sistema getSistema() {
		return sistema;
	}

	public SistemaMunicipio() 
	{

	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}

	public Municipio getMunicipio() {
		return municipio;
	}

	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	private Municipio municipio;
	private String regiao;

}