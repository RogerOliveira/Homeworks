package br.com.usjt.watersee.model;

public class Municipio {
	private int id;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private String nome;
	private String regiao;

	public Municipio(String nome, String regiao) {
		this.nome = nome;
		this.regiao = regiao;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	// fazer metodo imprimir em todas as classe
}