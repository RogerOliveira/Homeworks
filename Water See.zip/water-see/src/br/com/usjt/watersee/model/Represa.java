package br.com.usjt.watersee.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

public class Represa {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private Sistema sistema;
	private String nome;
	private String regiao;
	private double nivelTotal;

	public Represa() {

	}

	public Represa(Sistema sistema, String nome, String regiao, double nivelTotal) {

	}

	public String toString() {
		return nome;
	}

	public Sistema getSistema() {
		return sistema;
	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}
	public double getNivelTotal()
	{
		return nivelTotal;
	}
	public void setNivelTotal(double nivelTotal)
	{
		this.nivelTotal = nivelTotal;
	}

	public int getCodigoRepresa(Connection conn) {
		String sqlSelect = "SELECT * FROM TB_REPRESA WHERE TX_NOME = ?";
		try (PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setString(1, getNome());
			ResultSet rs = stm.executeQuery();
			if (rs.next()) {
				return rs.getInt("ID_REPRESA");
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return -1;
	}

	public ArrayList<String> carregar(Connection conn, String s) {
		ArrayList<String> lista = new ArrayList<String>();

		String sqlSelect = "SELECT * FROM TB_REPRESA R INNER JOIN TB_SISTEMA S ON(R.ID_SISTEMA_FK = S.ID_SISTEMA) WHERE S.TX_NOME = ?";

		try (PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
			stm.setString(1, s);
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				lista.add(rs.getString("tx_nome"));
			}
		} catch (SQLException e1) {
			System.out.print(e1.getStackTrace());
		}
		return lista;
	}
	public void alterarNivel(Connection conn, double novoNivel)
	{
		String sqlUpdate = "UPDATE tb_nivel SET db_nivel_total = ? WHERE id_represa = ?";
		
		try(PreparedStatement stm = conn.prepareStatement(sqlUpdate);)
		{
			stm.setDouble(1,getNivelTotal());
			stm.setInt(2, getId());
			stm.execute();
		}catch(SQLException e1)
		{
			System.out.println(e1.getStackTrace());
		}
		
	}
	

}