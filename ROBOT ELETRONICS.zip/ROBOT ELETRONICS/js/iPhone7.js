$(document).ready(
  function() {

   

	//array de motos
    var cont  = 0;
    var moto  = new Array();
    var preco = new Array();
    var ano   = new Array();

    moto [0] = "images/Iphone7.jpg";
    ano  [0] = "2016";
    preco[0] = "R$ 4.299,00";

    moto [1] = "images/Ihone7.jpg";

    moto [2] = "images/Iphon7.jpg";

    moto [3] = "images/fone7.jpg";

    moto [4] = "images/no7.jpg";
    
	carregaMoto(0);
      
    //carrega os thumbs
    cols = Math.floor(12/(moto.length));
    for(i = 0; i < moto.length; i++) {
        bloco = "<div class='col-md-" + cols + "'><img src='" + moto[i] + "' class='btThumb img-responsive' data-idx='" + i + "' /></div>";
        $("#thumbs").append(bloco);
    }
    // nomeMoto
    function nomeMoto(imgMoto) {
        var aux = imgMoto.split("/");
        var nomeMoto = aux[1].split(".");
        return nomeMoto[0];
    }
	// carregaMoto
    function carregaMoto(idx) {
		$("#imgGde").hide().attr("src",moto[idx]).fadeIn();
        var nMoto = nomeMoto(moto[idx]);
        var texto = nMoto + " [" + ano[idx] + "]: " + preco[idx];
        $("#legenda").html(texto);
        
    }
	// id flechaDir
    $("#flechaDir").click(
		function() {
			cont = cont + 1;
			if (cont == moto.length) cont = 0;
			carregaMoto(cont);
          
		}
	);
	// id flechaEsq
    $("#flechaEsq").click(
		function() {
            cont = cont - 1;
            if (cont == -1) cont = moto.length - 1;
            carregaMoto(cont);
           
        }
	);
    // click class brThumb
    $(document).on("click",".btThumb",
		function() {
			cont = $(this).data("idx");
			carregaMoto(cont);
			$(".boxForm").fadeOut("slow");
		}
	);
    // click id carrinho
    $(document).click(
		function() {
			nMoto = nomeMoto(moto[cont]);
			pMoto = preco[cont];
			aMoto = ano[cont];
			$("#fNomeMoto").html(nMoto); 
			$("#fPrecoMoto").html(pMoto);
			$("#fAnoMoto").html(aMoto);
			$(".boxForm").fadeIn("slow");
		}
	);
  }
);