
$(document).ready(
  function() {

	//array de imagens
  var cont  = 0;
  var imagem  = new Array();
  var proxima;
  

  imagem [0] = "images/macbookpro.png";  


  imagem [1] = "images/iphone7.png";
  

  imagem [2] = "images/applewatch.png";      
  

  carregaImagem(0);

  
	// carregaImagem
  function carregaImagem(idx) {
    $("#imgGde").hide().attr("src",imagem[idx]).fadeIn();       


  }



	// id flechaDireita
  $("#flechaDir").click(
    function() {
     cont = cont + 1;
     if (cont == imagem.length) cont = 0;
     carregaImagem(cont);
     $(".boxForm").hide();
   }
   );
	// id flechaEsquerda
  $("#flechaEsq").click(
    function() {
      cont = cont - 1;
      if (cont == -1) cont = imagem.length - 1;
      carregaImagem(cont);
      $(".boxForm").hide();
    }
    );



          var defaults = {
         
        scrollSpeed: 1200,
        easingType: 'linear' 
      };


   //só mostra o batao no final da pagian
   $().UItoTop({ easingType: 'easeOutQuart' });

 }

 );

